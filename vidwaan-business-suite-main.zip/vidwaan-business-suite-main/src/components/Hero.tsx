import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export const Hero = () => {
  const handleWhatsApp = () => {
    window.open("https://wa.me/919876543210?text=Hi, I want to know more about your services", "_blank");
  };

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary via-primary to-[hsl(250,65%,45%)]">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjA1IiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20"></div>
      
      <div className="container relative z-10 px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-1000">
          <div className="inline-block px-4 py-2 bg-accent/90 text-accent-foreground rounded-full text-sm font-semibold mb-4 shadow-lg">
            ✓ Trusted by 1000+ Businesses
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
            Register Your Company in
            <span className="block text-accent mt-2">Just 7 Days</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto">
            Starting at Only <span className="font-bold text-accent">₹5,999</span> (All Govt Fees Included)
          </p>
          
          <div className="flex flex-wrap gap-3 justify-center text-white/80 text-sm md:text-base">
            <span>Private Limited</span>
            <span>•</span>
            <span>LLP</span>
            <span>•</span>
            <span>OPC</span>
            <span>•</span>
            <span>GST</span>
            <span>•</span>
            <span>ITR</span>
            <span>•</span>
            <span>Trademark</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button 
              size="lg" 
              onClick={handleWhatsApp}
              className="bg-accent text-accent-foreground hover:bg-accent/90 shadow-2xl hover:shadow-accent/50 transition-all duration-300 text-lg px-8 py-6 group"
            >
              Start Registration
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm text-lg px-8 py-6"
            >
              Explore Services
            </Button>
          </div>

          <div className="flex flex-wrap justify-center gap-8 pt-8 text-white/70 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-accent text-xl">✓</span>
              <span>Zero Hidden Charges</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-accent text-xl">✓</span>
              <span>Free Expert Consultation</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-accent text-xl">✓</span>
              <span>7-Day Delivery Guarantee</span>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent"></div>
    </section>
  );
};
