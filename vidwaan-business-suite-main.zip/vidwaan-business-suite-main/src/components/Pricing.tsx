import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

const pricingPlans = [
  {
    name: "Basic",
    price: "5,999",
    originalPrice: "12,000",
    popular: false,
    features: [
      "Name Approval (2 Options)",
      "2 Director Identification Numbers (DIN)",
      "2 Digital Signatures (Class-3 DSC)",
      "Memorandum & Articles of Association",
      "Company PAN + TAN",
      "Incorporation Certificate",
      "Bank Account Opening",
    ],
  },
  {
    name: "Standard",
    price: "9,999",
    originalPrice: "18,000",
    popular: true,
    features: [
      "Everything in Basic Package",
      "GST Registration Included",
      "Bank Account Opening Assistance",
      "3 Months Free Accounting & Bookkeeping",
      "Commencement of Business Filing",
      "Free Consultation for 1 Year",
      "Share Certificates (Physical + Digital)",
    ],
  },
  {
    name: "Premium",
    price: "14,999",
    originalPrice: "28,000",
    popular: false,
    features: [
      "Everything in Standard Package",
      "Trademark Filing (1 Class)",
      "1 Year GST Return Filing",
      "MSME + Import Export Code (IEC)",
      "Dedicated CA Support for 1 Year",
      "Priority Processing (5 Days)",
      "First Board Resolution + Minutes",
    ],
  },
];

export const Pricing = () => {
  const handleWhatsApp = (plan: string, price: string) => {
    window.open(`https://wa.me/919876543210?text=Hi, I want ${plan} Company Registration ₹${price}`, "_blank");
  };

  return (
    <section className="py-20 bg-background">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Private Limited Company Registration Packages
          </h2>
          <p className="text-lg text-muted-foreground">
            Choose the perfect plan — All include Government Fees, DIN, DSC, MOA/AOA, PAN/TAN
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <Card 
              key={index}
              className={`relative hover:shadow-2xl transition-all duration-300 ${
                plan.popular 
                  ? 'border-primary border-2 shadow-xl scale-105' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground">
                  MOST POPULAR
                </Badge>
              )}
              
              <CardHeader className="text-center pb-8 pt-8">
                <CardTitle className="text-2xl mb-4">{plan.name}</CardTitle>
                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-4xl md:text-5xl font-bold text-foreground">₹{plan.price}</span>
                  </div>
                  <div className="text-muted-foreground line-through text-lg">
                    ₹{plan.originalPrice}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  onClick={() => handleWhatsApp(plan.name, plan.price)}
                  className={`w-full text-base py-6 ${
                    plan.popular 
                      ? 'bg-accent text-accent-foreground hover:bg-accent/90' 
                      : 'bg-primary text-primary-foreground hover:bg-primary/90'
                  }`}
                >
                  Choose {plan.name}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-6 mt-12 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 text-primary" />
            <span>Zero Hidden Charges</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 text-primary" />
            <span>Free Expert Consultation</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 text-primary" />
            <span>7-Day Delivery Guarantee</span>
          </div>
        </div>
      </div>
    </section>
  );
};
