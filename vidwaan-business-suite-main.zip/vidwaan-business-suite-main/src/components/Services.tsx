import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Building2, Receipt, Utensils, FileCheck, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Building2,
    title: "Company & LLP Registration",
    description: "Register your Private Limited, LLP, OPC, or Partnership firm with complete documentation and government fee inclusion.",
    features: ["DIN & DSC", "MOA/AOA", "PAN/TAN", "Certificate"],
  },
  {
    icon: Receipt,
    title: "GST Registration & Filing",
    description: "Complete GST registration and monthly/quarterly return filing services with expert guidance.",
    features: ["GSTR-1", "GSTR-3B", "Annual Return", "Compliance"],
  },
  {
    icon: FileText,
    title: "ITR Filing",
    description: "Individual and business income tax return filing with maximum refund optimization.",
    features: ["ITR-1 to ITR-7", "Tax Planning", "Refund Claims", "Notice Support"],
  },
  {
    icon: Utensils,
    title: "Food Licence (FSSAI)",
    description: "Get your food business registered with FSSAI - Basic, State, and Central licenses available.",
    features: ["Registration", "State License", "Central License", "Renewal"],
  },
  {
    icon: FileCheck,
    title: "ROC Filings & Compliance",
    description: "Annual ROC filings, form submissions, and company compliance management.",
    features: ["Annual Returns", "Form MGT-7", "Form AOC-4", "DIR-3 KYC"],
  },
  {
    icon: Calculator,
    title: "Audit Services",
    description: "Comprehensive audit services including statutory, tax, and internal audits.",
    features: ["Statutory Audit", "Tax Audit", "Internal Audit", "GST Audit"],
  },
];

export const Services = () => {
  const handleWhatsApp = (service: string) => {
    window.open(`https://wa.me/919876543210?text=Hi, I want to know more about ${service}`, "_blank");
  };

  return (
    <section id="services" className="py-20 bg-secondary/30">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Our Professional Services
          </h2>
          <p className="text-lg text-muted-foreground">
            Complete business solutions from company registration to compliance management
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card 
                key={index} 
                className="group hover:shadow-xl transition-all duration-300 border-2 hover:border-primary/50 hover:-translate-y-1 bg-card"
              >
                <CardHeader>
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-muted-foreground">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mr-3"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={() => handleWhatsApp(service.title)}
                    variant="outline" 
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};
